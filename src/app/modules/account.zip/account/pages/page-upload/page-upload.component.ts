import { Component, OnInit, TemplateRef } from '@angular/core';
import { ImageCroppedEvent } from 'ngx-image-cropper';

@Component({
  selector: 'app-page-upload',
  templateUrl: './page-upload.component.html',
  styleUrls: ['./page-upload.component.scss']
})
export class PageUploadComponent implements OnInit {
  

  imageChangedEvent: any = '';
  croppedImage: any = './assets/images/avatars/avatar-3.jpg';

  fileChangeEvent(event: any): void {
    this.imageChangedEvent = event;
}
imageCropped(event: ImageCroppedEvent) {
    this.croppedImage = event.base64;
}
imageLoaded() {
    // show cropper
}
cropperReady() {
    // cropper ready
}
loadImageFailed() {
    // show message
}

  constructor() { }

  ngOnInit(): void {
  }
  src='./assets/images/avatars/avatar-3.jpg';
    onSelectFile(event) {
        if (event.target.files && event.target.files[0]) {
          var reader = new FileReader();
    
          reader.readAsDataURL(event.target.files[0]); // read file as data url
    
          reader.onload = (event:any) => { // called once readAsDataURL is completed
            this.src = event.target.result;
          }
        }
      }
}
